class RecaptchaResult {
  final String? verificationId;

  const RecaptchaResult(this.verificationId);
}
