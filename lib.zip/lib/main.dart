import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'firebase_options.dart';


import 'app.dart';

// TODO(codelab user): Get API key
const clientId = '402310869017-2a9oc3hpdi8v3eaesi3bq5uvkl1evphg.apps.googleusercontent.com';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyApp());
}