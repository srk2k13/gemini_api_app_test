
import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:firebase_ui_auth/firebase_ui_auth.dart';





const apiKey = 'AIzaSyDMutxmgbRhdi24tw48PjgvhOv8Lezs6L0';
const projectId = 'gen-lang-client-0635026112';
const geminiclientId = '856935191802-pnatcti14gv14fpbv198gvil2eof1pkt.apps.googleusercontent.com';


class GeminiChatHome extends StatefulWidget {
  const GeminiChatHome({super.key});
  @override
  _GeminiChatHomeState createState() => _GeminiChatHomeState();
}

class _GeminiChatHomeState extends State<GeminiChatHome> {
  final _textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Text('Gemini '),
        ),
        body: Padding(
          padding: const EdgeInsets.all(20.0),

          child: SingleChildScrollView(

            child: Column(
              children: [
                SizedBox(height: 20),
                TextFormField(
                  controller: _textController,
                  decoration: InputDecoration(
                    labelText: 'Enter a prompt here ',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () async {
                    final model = GenerativeModel(
                      model: 'gemini-1.5-pro',
                      //model: 'text-ada-001',

                      apiKey: 'AIzaSyDMutxmgbRhdi24tw48PjgvhOv8Lezs6L0',
                    );
                    final prompt = _textController.text;
                    final content = [Content.text(prompt)];
                    final response = await model.generateContent(content);

                    setState(() {
                      _generatedText = response.text;
                    });
                  },
                  child: Text('Generate'),
                ),
                SizedBox(height: 20),
                Text(_generatedText ?? ''),

                const SignOutButton(),
              ],
            ),
          ),
        )
    );
  }

  String? _generatedText;
}