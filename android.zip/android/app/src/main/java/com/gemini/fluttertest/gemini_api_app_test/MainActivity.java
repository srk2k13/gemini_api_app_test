package com.gemini.fluttertest.gemini_api_app_test;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
